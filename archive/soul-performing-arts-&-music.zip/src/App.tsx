import { useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Programs from './components/Programs';
import MusicQuiz from './components/MusicQuiz';
import BookingForm from './components/BookingForm';
import Instructors from './components/Instructors';
import Reviews from './components/Reviews';
import FAQ from './components/FAQ';
import Footer from './components/Footer';
import { Award, ShieldCheck, Zap, Heart, Star, Compass } from 'lucide-react';

export default function App() {
  const [selectedInstrument, setSelectedInstrument] = useState<string>('');
  const [isSpiritDiscountApplied, setIsSpiritDiscountApplied] = useState<boolean>(false);

  const handleSelectInstrument = (instrumentId: string) => {
    setSelectedInstrument(instrumentId);
  };

  const handleApplyDiscount = () => {
    setIsSpiritDiscountApplied(true);
  };

  const handleClearSelected = () => {
    setSelectedInstrument('');
  };

  return (
    <div className="min-h-screen bg-[#FDFBF7] text-[#1A1A1A] selection:bg-brand-gold selection:text-white overflow-x-hidden">
      {/* 0. Core Responsive Translucent Header */}
      <Navbar />

      {/* 1. Atmospheric Spotlight Hero Panel */}
      <Hero />

      {/* 2. Interactive Music Program Catalog */}
      <Programs onSelectInstrument={handleSelectInstrument} />

      {/* 3. "The Soul Experience" - Why We Stand Out */}
      <section className="py-24 bg-[#FDFBF7] relative overflow-hidden border-b border-[#1A1A1A]/10 text-left">
        {/* Soft geometric lines backgrounds */}
        <div className="absolute left-1/3 top-1/4 w-96 h-96 rounded-full bg-brand-gold/5 border border-brand-gold/10 blur-[80px] pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Highlights Header Left (5 Columns) */}
            <div className="lg:col-span-5 space-y-6">
              <span className="text-xs uppercase font-extrabold tracking-[0.25em] text-brand-gold">
                Academy Standard
              </span>
              <h2 className="font-serif text-3xl sm:text-4xl font-black text-[#1A1A1A] uppercase tracking-tight">
                The Soul Experience
              </h2>
              <div className="w-16 h-0.5 bg-brand-gold" />
              
              <p className="font-sans text-sm text-[#1A1A1A]/85 font-light leading-relaxed">
                We believe that learning music should never feel like a high-stress assembly line. At <strong>Soul Performing Arts & Music</strong>, your educational path is calibrated to your natural speed, fostering active joy and deep self-discipline.
              </p>

              <div className="p-5 rounded-none bg-[#FAF6F0] border border-[#1A1A1A]/10 space-y-3">
                <blockquote className="font-sans text-xs sm:text-sm text-[#1A1A1A]/80 italic">
                  "Our core mandate is not to produce robot-like players of scales—but rather to ignite an authentic, lifelong relationship with sound, rhythm, and artistic courage."
                </blockquote>
                <div className="flex items-center gap-2 pt-1 border-t border-[#1A1A1A]/5">
                  <span className="text-xs font-bold text-brand-gold">Sarah Lim</span>
                  <span className="text-[10px] text-[#1A1A1A]/50 uppercase">— Founder & Principal</span>
                </div>
              </div>
            </div>

            {/* highlights Bento list Right (7 Columns) */}
            <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-6">
              
              {/* Highlight 1 */}
              <div className="p-6 bg-[#FAF6F0] border border-[#1A1A1A]/10 hover:border-brand-gold/30 rounded-none transition-all duration-300 space-y-3 shadow-sm">
                <div className="w-9 h-9 rounded-none bg-brand-gold/10 border border-brand-gold/25 flex items-center justify-center text-brand-gold">
                  <Compass className="w-4.5 h-4.5" />
                </div>
                <h4 className="font-serif font-black text-base text-[#1A1A1A] tracking-wide">
                  Personalized Roadmap
                </h4>
                <p className="font-sans text-xs text-[#1A1A1A]/70 leading-relaxed">
                  Individual slots are custom-designed around your unique speed, goals and genre preferences. Grow under a dedicated musical guide.
                </p>
              </div>

              {/* Highlight 2 */}
              <div className="p-6 bg-[#FAF6F0] border border-[#1A1A1A]/10 hover:border-brand-gold/30 rounded-none transition-all duration-300 space-y-3 shadow-sm">
                <div className="w-9 h-9 rounded-none bg-brand-gold/10 border border-brand-gold/25 flex items-center justify-center text-brand-gold">
                  <Star className="w-4.5 h-4.5" />
                </div>
                <h4 className="font-serif font-black text-base text-[#1A1A1A] tracking-wide">
                  International Syllabus
                </h4>
                <p className="font-sans text-xs text-[#1A1A1A]/70 leading-relaxed">
                  Prepare for world-accredited exams including ABRSM (London), Trinity College London, and Rockschool graded courses.
                </p>
              </div>

              {/* Highlight 3 */}
              <div className="p-6 bg-[#FAF6F0] border border-[#1A1A1A]/10 hover:border-brand-gold/30 rounded-none transition-all duration-300 space-y-3 shadow-sm">
                <div className="w-9 h-9 rounded-none bg-brand-gold/10 border border-brand-gold/25 flex items-center justify-center text-brand-gold">
                  <Zap className="w-4.5 h-4.5" />
                </div>
                <h4 className="font-serif font-black text-base text-[#1A1A1A] tracking-wide">
                  Live Stage Recitals
                </h4>
                <p className="font-sans text-xs text-[#1A1A1A]/70 leading-relaxed">
                  We don't just instruct isolated classes. Our team organizes regular stage recitals to spark high performance confidence.
                </p>
              </div>

              {/* Highlight 4 */}
              <div className="p-6 bg-[#FAF6F0] border border-[#1A1A1A]/10 hover:border-brand-gold/30 rounded-none transition-all duration-300 space-y-3 shadow-sm">
                <div className="w-9 h-9 rounded-none bg-brand-gold/10 border border-brand-gold/25 flex items-center justify-center text-brand-gold">
                  <ShieldCheck className="w-4.5 h-4.5" />
                </div>
                <h4 className="font-serif font-black text-base text-[#1A1A1A] tracking-wide">
                  Flexible Make-Up Classes
                </h4>
                <p className="font-sans text-xs text-[#1A1A1A]/70 leading-relaxed">
                  Illness or school exams? Inform us 24 hours in advance, and we will schedule an individual makeup session with ease.
                </p>
              </div>

            </div>

          </div>

        </div>
      </section>

      {/* 4. Interactive Music Spirit Quiz Widget */}
      <MusicQuiz
        onSelectInstrument={handleSelectInstrument}
        onApplyDiscount={handleApplyDiscount}
      />

      {/* 5. Scheduling Booking Form Dashboard */}
      <BookingForm
        selectedInstrumentId={selectedInstrument}
        onClearSelectedInstrument={handleClearSelected}
        isSpiritDiscountApplied={isSpiritDiscountApplied}
      />

      {/* 6. Professional Instructor Bios */}
      <Instructors />

      {/* 7. Bento Grid Client Testimonies */}
      <Reviews />

      {/* 8. Common FAQ Accordion Module */}
      <FAQ />

      {/* 9. Premium Contacts Map coordinates and Footer */}
      <Footer />
    </div>
  );
}
