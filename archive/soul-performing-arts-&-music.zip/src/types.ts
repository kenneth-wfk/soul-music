export interface Booking {
  id: string;
  studentName: string;
  studentAge: number;
  instrument: string;
  skillLevel: 'Beginner' | 'Intermediate' | 'Advanced';
  preferredDay: string;
  preferredTime: string;
  contactWhatsApp: string;
  bookingDate: string;
  status: 'Received' | 'Scheduling' | 'Confirmed';
  ticketCode: string;
  specialInstructions?: string;
  spiritDiscountApplied?: boolean;
}

export interface Program {
  id: string;
  name: string;
  tagline: string;
  iconName: string; // Lucide icon lookup string
  description: string;
  priceLabel: string;
  trialPrice: string;
  durationLevel: string;
  ageGroup: string;
  syllabusOverview: string[];
  image: string;
  targetInterests: string[];
}

export interface Instructor {
  id: string;
  name: string;
  role: string;
  bio: string;
  instrument: string;
  image: string;
  education: string;
  experience: string;
}

export interface FaqItem {
  question: string;
  answer: string;
  category: string;
}

export interface ReviewItem {
  id: string;
  author: string;
  relation: string; // "Parent" | "Adult Student" | "Alumni"
  rating: number;
  content: string;
  instrument: string;
  avatarId: string; // avatar initials or seed
}
