import { Facebook, Music, MapPin, Phone, Mail, Clock, ShieldCheck, Heart, Sparkles } from 'lucide-react';

export default function Footer() {
  return (
    <footer id="location" className="bg-[#1A1A1A] border-t border-[#1A1A1A] relative pt-16 pb-8 text-left text-[#FAF6F0]/70">
      
      {/* Decorative Blur */}
      <div className="absolute right-0 bottom-0 w-80 h-80 rounded-full bg-brand-gold/5 blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Core Info Row */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 md:gap-12 pb-12 border-b border-[#FAF6F0]/10">
          
          {/* Column 1: Brand pitch (5 Cols) */}
          <div className="md:col-span-5 space-y-4 text-left">
            <a href="#" className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-none bg-brand-gold flex items-center justify-center p-2">
                <Music className="w-5 h-5 text-[#1A1A1A]" />
              </div>
              <div>
                <span className="font-serif text-lg font-black tracking-tight text-[#FAF6F0] block leading-none">
                  SOUL
                </span>
                <span className="text-[9px] uppercase font-semibold text-brand-gold tracking-[0.16em] block mt-0.5">
                  Performing Arts & Music
                </span>
              </div>
            </a>
            
            <p className="font-sans text-xs sm:text-sm text-[#FAF6F0]/60 font-light leading-relaxed max-w-sm">
              An encouraging, premium music academy based in Kampar, Perak, Malaysia. We craft personalized roadmap lessons that blend technical theory with pure stage performance confidence.
            </p>

            {/* Social Anchor */}
            <div className="flex items-center gap-3 pt-2">
              <a
                href="https://www.facebook.com/soulperformingmusic"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-none bg-[#FAF6F0]/5 border border-[#FAF6F0]/10 flex items-center justify-center text-brand-gold hover:text-white hover:bg-brand-gold hover:border-brand-gold transition-all duration-300 shadow"
                aria-label="Find us on Facebook"
              >
                <Facebook className="w-4 h-4 fill-current" />
              </a>
              <span className="text-[11px] font-sans font-medium text-[#FAF6F0]/40">
                Official FB Handle: @soulperformingmusic
              </span>
            </div>
          </div>

          {/* Column 2: Venue Hours (3 Cols) */}
          <div className="md:col-span-3 space-y-4">
            <h4 className="font-serif text-sm font-black text-[#FAF6F0] uppercase tracking-wider flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-brand-gold" />
              <span>Studio Hours</span>
            </h4>
            
            <ul className="space-y-2.5 font-sans text-xs sm:text-sm text-[#FAF6F0]/60 font-light">
              <li className="flex justify-between border-b border-[#FAF6F0]/10 pb-1.5">
                <span>Weekdays (Mon - Fri)</span>
                <span className="text-[#FAF6F0] font-bold">1:30 PM - 9:30 PM</span>
              </li>
              <li className="flex justify-between border-b border-[#FAF6F0]/10 pb-1.5">
                <span>Saturday</span>
                <span className="text-[#FAF6F0] font-bold">9:00 AM - 7:00 PM</span>
              </li>
              <li className="flex justify-between border-b border-[#FAF6F0]/10 pb-1.5">
                <span>Sunday</span>
                <span className="text-[#FAF6F0] font-bold">9:30 AM - 6:30 PM</span>
              </li>
              <li className="text-red-400 text-[10px] uppercase font-bold tracking-widest flex items-center gap-1 mt-1">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Public Holidays: Closed</span>
              </li>
            </ul>
          </div>

          {/* Column 3: Contact details (4 Cols) */}
          <div className="md:col-span-4 space-y-4 text-left">
            <h4 className="font-serif text-sm font-black text-[#FAF6F0] uppercase tracking-wider flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-brand-gold" />
              <span>Contact & Location</span>
            </h4>
            
            <ul className="space-y-3 font-sans text-xs sm:text-sm text-[#FAF6F0]/60 font-light">
              <li className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-brand-gold shrink-0 mt-0.5" />
                <span>
                  No. 22, Jalan Kolej, Taman Kolej Perdana, 31900 Kampar, Perak, Malaysia
                </span>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-brand-gold shrink-0" />
                <a href="tel:+60163387890" className="hover:text-brand-gold transition-colors font-mono font-bold">
                  +60 16-338 7890
                </a>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-brand-gold shrink-0" />
                <a href="mailto:hello@soulperformingmusic.com" className="hover:text-brand-gold transition-colors font-mono font-bold">
                  hello@soulperformingmusic.com
                </a>
              </li>
            </ul>
          </div>

        </div>

        {/* Floating Bottom details */}
        <div className="flex flex-col sm:flex-row items-center justify-between pt-8 text-[11px] text-[#FAF6F0]/40 font-sans gap-4">
          <div className="text-center sm:text-left">
            <p>&copy; {new Date().getFullYear()} Soul Performing Arts & Music Sdn. Bhd. All Rights Reserved.</p>
            <p className="text-[9px] text-[#FAF6F0]/30 mt-0.5">Approved under Malaysian Music Academy registries. Graded syllabus with Trinity & ABRSM frameworks.</p>
          </div>

          <div className="flex items-center gap-1 text-[#FAF6F0]/30">
            <ShieldCheck className="w-3.5 h-3.5 text-brand-gold/30" />
            <span>Secure Client Dashboard Platform</span>
          </div>
        </div>

      </div>
    </footer>
  );
}
