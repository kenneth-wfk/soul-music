import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, ArrowRight, HelpCircle, RotateCcw, Check, Disc, Star } from 'lucide-react';

interface QuizProps {
  onSelectInstrument: (instrumentId: string) => void;
  onApplyDiscount: () => void;
}

interface Question {
  id: number;
  text: string;
  options: {
    text: string;
    scores: Record<string, number>;
  }[];
}

const QUESTIONS: Question[] = [
  {
    id: 1,
    text: 'When listening to your favorite songs, which element naturally commands your focus first?',
    options: [
      { text: 'A clean, thumping physical beat that dictates the space.', scores: { drums: 3, guitar: 1 } },
      { text: 'An elegant, soaring melody line that pulls at your emotions.', scores: { violin: 3, vocal: 1 } },
      { text: 'Rich, layered harmonic chords working beautifully in the background.', scores: { piano: 3, guitar: 1 } },
      { text: 'Raw, beautiful human lyrics delivered with direct vocal expression.', scores: { vocal: 3, piano: 1 } },
      { text: 'A fiery, expressive string bend or crisp acoustic fingerpicking pattern.', scores: { guitar: 3, drums: 1 } }
    ]
  },
  {
    id: 2,
    text: 'Choose the statement that best mirrors your ideal creative energy level:',
    options: [
      { text: 'High adrenaline, physical, explosive coordination and timing.', scores: { drums: 3 } },
      { text: 'Sophisticated, precise, deeply focused and classically structural.', scores: { violin: 3, piano: 1 } },
      { text: 'Versatile, layered, capable of playing complete symphonies in solo.', scores: { piano: 3 } },
      { text: 'Directly personal, warm, highly communicative and lyrics-driven.', scores: { vocal: 3 } },
      { text: 'Free-spirited, portable, responsive to chords and quick jamming.', scores: { guitar: 3 } }
    ]
  },
  {
    id: 3,
    text: 'If you had to master a complex physical skill, how would you prefer to practice?',
    options: [
      { text: 'Locking into a solid, repetitive tempo routine to build muscle endurance.', scores: { drums: 3 } },
      { text: 'Repeating delicate adjustments to find the absolute millimeter positioning.', scores: { violin: 3 } },
      { text: 'Studying structural configurations, reading sheets, and multi-handling keys.', scores: { piano: 3 } },
      { text: 'Calibrating posture, deep lung expansion, and vocal resonance.', scores: { vocal: 3 } },
      { text: 'Focusing on finger speed, tactile pressure on frets, and chord changes.', scores: { guitar: 3 } }
    ]
  }
];

const INSTRUMENT_PROFILES: Record<string, {
  name: string;
  brandName: string;
  tagline: string;
  description: string;
  colorClass: string;
  icon: string;
}> = {
  piano: {
    name: 'Classical & Pop Piano',
    brandName: 'piano',
    tagline: 'The Harmonic Architect',
    description: 'You appreciate structure, detail, and rich polyphonic textures. Able to balance multiple voices at once, you possess the patience and vision to draft breathtaking musical landscapes.',
    colorClass: 'text-amber-300 border-amber-300/30 bg-amber-500/10',
    icon: '🎹'
  },
  guitar: {
    name: 'Acoustic & Electric Guitar',
    brandName: 'guitar',
    tagline: 'The Versatile Lyricist',
    description: 'A free-spirit who loves immediate expressive freedom. You appreciate the combination of rhythmic strumming and melodic freedom, capable of setting the campfire mood or rock-shred stage.',
    colorClass: 'text-indigo-300 border-indigo-300/30 bg-indigo-500/10',
    icon: '🎸'
  },
  vocal: {
    name: 'Vocal Masterclass',
    brandName: 'vocal',
    tagline: 'The Direct Communicator',
    description: 'You carry your instrument within you. Deeply communicative, lyrical, and empathetic, you relate to lyrics on a primal lvl and possess the capacity to deliver absolute emotional truth directly.',
    colorClass: 'text-rose-300 border-rose-300/30 bg-rose-500/10',
    icon: '🎤'
  },
  violin: {
    name: 'Violin & String Coaching',
    brandName: 'violin',
    tagline: 'The Soulful Intonator',
    description: 'Possessing a rare standard of pitch sensitivity and micro-discipline. You value micro-controls, delicate posture, and deep classical expressions that weep with graceful bows.',
    colorClass: 'text-cyan-300 border-cyan-300/30 bg-cyan-500/10',
    icon: '🎻'
  },
  drums: {
    name: 'Drums & Rhythm Beats',
    brandName: 'drums',
    tagline: 'The Rhythmic Engine',
    description: 'The heartbeat of any group performance. Explosive, highly coordinated, and holding immense visceral kinetic power. You think in tempos, limb division, and drive massive group energy.',
    colorClass: 'text-emerald-300 border-emerald-300/30 bg-emerald-500/10',
    icon: '🥁'
  }
};

export default function MusicQuiz({ onSelectInstrument, onApplyDiscount }: QuizProps) {
  const [currentStep, setCurrentStep] = useState<number>(0); // 0 (start), 1, 2, 3 (questions), 4 (result)
  const [scores, setScores] = useState<Record<string, number>>({
    piano: 0,
    guitar: 0,
    vocal: 0,
    violin: 0,
    drums: 0
  });
  const [selectedOption, setSelectedOption] = useState<number | null>(null);

  const resetQuiz = () => {
    setCurrentStep(0);
    setScores({ piano: 0, guitar: 0, vocal: 0, violin: 0, drums: 0 });
    setSelectedOption(null);
  };

  const startQuiz = () => {
    setCurrentStep(1);
    setSelectedOption(null);
  };

  const handleOptionSelect = (index: number) => {
    setSelectedOption(index);
  };

  const handleNext = () => {
    if (selectedOption === null) return;
    
    // Add score multiplier
    const question = QUESTIONS[currentStep - 1];
    const option = question.options[selectedOption];
    const newScores = { ...scores };
    
    for (const [key, value] of Object.entries(option.scores)) {
      if (key in newScores) {
        newScores[key] = (newScores[key] || 0) + value;
      }
    }
    
    setScores(newScores);
    setSelectedOption(null);

    if (currentStep < QUESTIONS.length) {
      setCurrentStep(currentStep + 1);
    } else {
      setCurrentStep(4); // result
    }
  };

  // Determine highest score
  const getWinnerKey = () => {
    let maxScore = -1;
    let winner = 'piano';
    for (const key of Object.keys(scores)) {
      const val = scores[key];
      if (val > maxScore) {
        maxScore = val;
        winner = key;
      }
    }
    return winner;
  };

  const winnerKey = getWinnerKey();
  const matchedSpirit = INSTRUMENT_PROFILES[winnerKey] || INSTRUMENT_PROFILES.piano;

  const handleApplyToForm = () => {
    // Autofill matched brand ID
    onSelectInstrument(matchedSpirit.brandName);
    onApplyDiscount();
    
    // Scroll
    const formElement = document.getElementById('booking');
    if (formElement) {
      formElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="sound-quiz" className="py-24 bg-[#FDFBF7] relative overflow-hidden border-b border-[#1A1A1A]/10">
      
      {/* Visual Ambient Decor */}
      <div className="absolute left-1/10 top-1/4 w-72 h-72 rounded-full bg-[#C17D50]/5 blur-[80px] pointer-events-none" />
      <div className="absolute right-1/10 bottom-1/4 w-72 h-72 rounded-full bg-[#C17D50]/5 blur-[80px] pointer-events-none" />

      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        
        {/* Step 0: Welcome Screen */}
        {currentStep === 0 && (
          <div className="text-center rounded-none bg-[#FAF6F0] border border-[#1A1A1A]/10 p-8 sm:p-12 shadow-sm relative">
            <div className="w-16 h-16 bg-brand-gold/10 border border-brand-gold/30 rounded-none flex items-center justify-center mx-auto mb-6 text-brand-gold">
              <Disc className="w-8 h-8 animate-spin" style={{ animationDuration: '6s' }} />
            </div>
            
            <span className="text-xs uppercase font-extrabold tracking-[0.25em] text-brand-gold block mb-3">
              Interactive Explorer
            </span>
            <h2 className="font-serif text-2xl sm:text-4xl font-black text-[#1A1A1A] uppercase tracking-tight mb-4">
              Find Your "Sound Spirit"
            </h2>
            <p className="font-sans text-[#1A1A1A]/75 font-light text-sm sm:text-base max-w-xl mx-auto mb-8 leading-relaxed">
              Not sure which instrument is your soulmate? Take our customized 3-question psychological assessment. 
              Find the perfect discipline matching your natural reflexes and claim a <strong>10% Booking discount</strong> coupon.
            </p>

            <button
              onClick={startQuiz}
              className="inline-flex items-center gap-2.5 px-8 py-3.5 font-sans font-bold text-xs uppercase tracking-widest text-white bg-[#1A1A1A] hover:bg-brand-gold border border-[#1A1A1A] hover:border-brand-gold transition-all duration-300 rounded-none cursor-pointer shadow-sm"
            >
              Begin Assessment
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Step 1, 2, 3: Active Questions */}
        {currentStep >= 1 && currentStep <= 3 && (
          <div className="rounded-none bg-[#FAF6F0] border border-[#1A1A1A]/10 p-6 sm:p-10 shadow-sm space-y-6">
            
            {/* Steps Track Header */}
            <div className="flex items-center justify-between pb-4 border-b border-[#1A1A1A]/10">
              <div className="flex items-center gap-2">
                <HelpCircle className="w-4.5 h-4.5 text-brand-gold" />
                <span className="font-sans text-xs uppercase tracking-widest font-extrabold text-brand-gold">
                  Question {currentStep} of 3
                </span>
              </div>
              <div className="flex items-center gap-1">
                {[1, 2, 3].map((step) => (
                  <div
                    key={step}
                    className={`w-6 h-1.5 rounded-none transition-all ${
                      step === currentStep 
                        ? 'bg-brand-gold w-10' 
                        : step < currentStep 
                        ? 'bg-brand-gold/40' 
                        : 'bg-gray-300'
                    }`}
                  />
                ))}
              </div>
            </div>

            {/* Question Text */}
            <h3 className="font-serif text-lg sm:text-xl md:text-2xl font-black text-[#1A1A1A] leading-snug">
              {QUESTIONS[currentStep - 1].text}
            </h3>

            {/* Options List */}
            <div className="space-y-3 pt-2">
              {QUESTIONS[currentStep - 1].options.map((opt, optIdx) => {
                const isSelected = selectedOption === optIdx;
                return (
                  <button
                    key={optIdx}
                    onClick={() => handleOptionSelect(optIdx)}
                    className={`w-full text-left px-5 py-3.5 rounded-none font-sans text-xs sm:text-sm transition-all border flex items-center justify-between pointer-events-auto cursor-pointer ${
                      isSelected
                        ? 'bg-brand-gold/10 border-[#1A1A1A] text-brand-gold font-bold shadow-xs'
                        : 'bg-[#FDFBF7] border-[#1A1A1A]/10 text-[#1A1A1A]/80 hover:border-[#1A1A1A]/30 hover:bg-[#FAF6F0]'
                    }`}
                  >
                    <span>{opt.text}</span>
                    <div className={`w-4.5 h-4.5 rounded-none border flex items-center justify-center shrink-0 ml-3 ${
                      isSelected 
                        ? 'border-brand-gold bg-brand-gold text-white' 
                        : 'border-[#1A1A1A]/20'
                    }`}>
                      {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Step Controls */}
            <div className="flex items-center justify-between pt-6 border-t border-[#1A1A1A]/10 mt-4">
              <button
                onClick={resetQuiz}
                className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-[#1A1A1A]/50 hover:text-brand-gold transition-colors"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Abort</span>
              </button>

              <button
                disabled={selectedOption === null}
                onClick={handleNext}
                className={`inline-flex items-center gap-1.5 px-6 py-3.5 rounded-none font-sans text-xs font-bold uppercase tracking-widest text-[#FDFBF7] ${
                  selectedOption !== null
                    ? 'bg-[#1A1A1A] hover:bg-brand-gold cursor-pointer transition-all duration-200 border border-[#1A1A1A] hover:border-brand-gold'
                    : 'bg-gray-200 text-gray-400 border border-gray-200 cursor-not-allowed'
                }`}
              >
                <span>{currentStep === 3 ? 'Show Spirit Instrument' : 'Next Step'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

          </div>
        )}

        {/* Step 4: Results Render */}
        {currentStep === 4 && (
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="rounded-none bg-[#FAF6F0] border border-brand-gold p-6 sm:p-10 shadow-sm relative overflow-hidden text-center space-y-6"
          >
            {/* Background spotlight */}
            <div className="absolute inset-0 bg-radial-at-c from-brand-gold/5 via-transparent to-transparent pointer-events-none" />

            <div className="inline-flex items-center gap-1 px-4 py-1 rounded-none bg-brand-gold/10 border border-brand-gold/30 text-brand-gold text-xs font-extrabold tracking-widest uppercase">
              <Star className="w-3.5 h-3.5 fill-brand-gold text-brand-gold" />
              <span>Assessment Completed</span>
            </div>

            <div className="space-y-1">
              <span className="block text-4xl sm:text-5xl md:text-6xl mb-2">{matchedSpirit.icon}</span>
              <span className="block text-xs uppercase font-extrabold tracking-[0.25em] text-brand-gold">
                {matchedSpirit.tagline}
              </span>
              <h3 className="font-serif text-3xl sm:text-4xl font-black text-[#1A1A1A] uppercase tracking-tight">
                {matchedSpirit.name}
              </h3>
            </div>

            <p className="font-sans text-[#1A1A1A]/80 font-light text-sm sm:text-base max-w-xl mx-auto leading-relaxed">
              {matchedSpirit.description}
            </p>

            {/* Virtual Voucher Card */}
            <div className="max-w-md mx-auto rounded-none bg-[#FDFBF7] border border-[#1A1A1A]/15 p-5 relative overflow-hidden flex flex-col sm:flex-row items-center justify-between gap-4 text-left shadow-sm">
              {/* Ticket cutouts decorations */}
              <div className="absolute left-0 -translate-x-1/2 w-4 h-4 rounded-full bg-[#FAF6F0]" />
              <div className="absolute right-0 translate-x-1/2 w-4 h-4 rounded-full bg-[#FAF6F0]" />
              
              <div className="space-y-1">
                <span className="block text-[9px] uppercase font-bold tracking-widest text-brand-gold">
                  Voucher Claim Approved
                </span>
                <span className="block font-serif text-lg sm:text-xl font-black text-[#1A1A1A] tracking-tight">
                  SOUND SPIRIT VOUCHER
                </span>
                <span className="block text-xs text-[#1A1A1A]/60">
                  10% OFF trial class enrollment fee (Matched: {matchedSpirit.name})
                </span>
              </div>
              <div className="bg-[#1A1A1A] text-white border border-[#1A1A1A] font-mono px-4 py-2 rounded-none text-sm font-bold text-center tracking-widest shrink-0 uppercase select-all shadow-sm">
                SOULSPIRIT10
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-center gap-4 pt-4">
              <button
                onClick={resetQuiz}
                className="px-6 py-3 rounded-none border border-[#1A1A1A]/20 hover:border-brand-gold hover:text-brand-gold transition-all text-xs font-bold text-[#1A1A1A]/60 uppercase tracking-widest flex items-center justify-center gap-1.5 cursor-pointer bg-transparent"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Retake Quiz</span>
              </button>

              <button
                onClick={handleApplyToForm}
                className="px-8 py-3.5 bg-brand-gold hover:bg-[#1A1A1A] text-white hover:scale-[1.01] flex items-center justify-center gap-2 rounded-none font-sans text-xs font-bold uppercase tracking-widest transition-all duration-300 shadow-sm cursor-pointer border border-brand-gold hover:border-[#1A1A1A]"
              >
                Autofill & Apply Code
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        )}

      </div>
    </section>
  );
}
