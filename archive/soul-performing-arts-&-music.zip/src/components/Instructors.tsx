import { INSTRUCTORS } from '../data';
import { Award, ChevronRight, GraduationCap, Heart } from 'lucide-react';

export default function Instructors() {
  return (
    <section id="mentors" className="py-24 bg-[#FDFBF7] relative border-b border-[#1A1A1A]/10">
      
      {/* Visual glowing sphere */}
      <div className="absolute right-10 bottom-10 w-72 h-72 rounded-full bg-brand-gold/5 blur-[90px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header Block */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-4">
          <span className="text-xs uppercase font-extrabold tracking-[0.25em] text-brand-gold">
            Certified Educators
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl font-black text-[#1A1A1A] uppercase tracking-tight">
            Meet Your Mentors
          </h2>
          <div className="w-16 h-0.5 bg-brand-gold mx-auto" />
          <p className="font-sans text-[#1A1A1A]/70 font-light text-sm sm:text-base">
            Music is caught, not just taught. Our master certified instructors are active performing professionals dedicated to fostering a positive, stress-free space.
          </p>
        </div>

        {/* Instructors Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {INSTRUCTORS.map((teacher) => (
            <div
              key={teacher.id}
              className="bg-[#FAF6F0] border border-[#1A1A1A]/10 hover:border-brand-gold/30 rounded-none overflow-hidden shadow-sm transition-all duration-300 flex flex-col group justify-between"
            >
              <div>
                {/* Photo frame */}
                <div className="aspect-[4/5] relative overflow-hidden bg-[#FAF6F0]">
                  <img
                    src={teacher.image}
                    alt={teacher.name}
                    className="w-full h-full object-cover select-none filter contrast-[102%] brightness-100 group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  {/* Accent tag */}
                  <div className="absolute bottom-3 left-3 bg-[#1A1A1A] border border-[#1A1A1A] text-[#FDFBF7] px-3 py-1 rounded-none text-[9px] font-sans uppercase font-bold tracking-widest">
                    {teacher.instrument.split(' & ')[0]}
                  </div>
                </div>

                {/* Info block */}
                <div className="p-5 space-y-3.5">
                  <div className="space-y-0.5 text-left">
                    <h4 className="font-serif text-base font-bold text-[#1A1A1A] tracking-wide group-hover:text-brand-gold transition-colors">
                      {teacher.name}
                    </h4>
                    <span className="block text-[10px] sm:text-xs text-[#1A1A1A]/60 font-sans italic">
                      {teacher.role}
                    </span>
                  </div>

                  <p className="font-sans text-xs text-[#1A1A1A]/75 font-light leading-relaxed text-left">
                    {teacher.bio}
                  </p>
                </div>
              </div>

              {/* Verified Credentials bar */}
              <div className="px-5 pb-5 pt-3 border-t border-[#1A1A1A]/5 bg-transparent space-y-2 mt-auto">
                <div className="flex items-start gap-1.5 text-left font-sans text-[11px] text-[#1A1A1A]/60">
                  <GraduationCap className="w-4 h-4 text-brand-gold shrink-0 mt-0.5" />
                  <span className="leading-tight truncate block font-medium" title={teacher.education}>
                    {teacher.education}
                  </span>
                </div>
                <div className="flex items-center gap-1.5 text-left font-sans text-[11px] text-[#1A1A1A]/60">
                  <Award className="w-4 h-4 text-brand-gold shrink-0" />
                  <span className="leading-tight truncate block font-medium">
                    {teacher.experience}
                  </span>
                </div>
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
