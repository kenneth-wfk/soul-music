import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Program } from '../types';
import { MUSIC_PROGRAMS } from '../data';
import { Music, Guitar, Mic, Drum, Sparkles, Baby, CheckCircle2, ArrowRight } from 'lucide-react';

const iconMap: Record<string, any> = {
  Music,
  Guitar,
  Mic,
  Drum,
  Sparkles,
  Baby,
};

interface ProgramsProps {
  onSelectInstrument: (instrumentId: string) => void;
}

export default function Programs({ onSelectInstrument }: ProgramsProps) {
  const [activeTab, setActiveTab] = useState<string>(MUSIC_PROGRAMS[0].id);

  const activeProgram = MUSIC_PROGRAMS.find((p) => p.id === activeTab) || MUSIC_PROGRAMS[0];
  const ActiveIconComp = iconMap[activeProgram.iconName] || Music;

  const handleQuickBook = (id: string) => {
    onSelectInstrument(id);
    const element = document.getElementById('booking');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="programs" className="py-24 bg-[#FAF6F0] relative border-b border-[#1A1A1A]/10">
      {/* Decorative background glow */}
      <div className="absolute right-0 top-1/3 w-80 h-80 rounded-full bg-brand-gold/5 blur-[90px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header Block */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-4">
          <span className="text-xs uppercase font-extrabold tracking-[0.25em] text-brand-gold">
            Premium Curriculums
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl font-black text-[#1A1A1A] uppercase tracking-tight">
            Our Music Programs
          </h2>
          <div className="w-16 h-0.5 bg-brand-gold mx-auto" />
          <p className="font-sans text-[#1A1A1A]/70 font-light text-sm sm:text-base">
            Whether preparing for globally recognized ABRSM graded master certifications, or exploring classic chord variations as an adult hobbyist, we have the ideal roadmap.
          </p>
        </div>

        {/* Outer Tabs / Layout Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 items-start">
          
          {/* Tab Selector Column (Left 1 Column) */}
          <div className="lg:col-span-1 flex flex-row lg:flex-col gap-2 overflow-x-auto pb-4 lg:pb-0 lg:overflow-x-visible scrollbar-thin">
            {MUSIC_PROGRAMS.map((prog) => {
              const TabIcon = iconMap[prog.iconName] || Music;
              const isSelected = activeTab === prog.id;
              
              return (
                <button
                  key={prog.id}
                  onClick={() => setActiveTab(prog.id)}
                  className={`flex items-center gap-3 px-4 py-3 font-sans text-xs font-bold uppercase tracking-widest whitespace-nowrap lg:whitespace-normal text-left transition-all duration-200 border w-full flex-1 md:flex-none ${
                    isSelected
                      ? 'bg-brand-gold border-[#1A1A1A] text-white shadow-sm'
                      : 'bg-[#FDFBF7] border-[#1A1A1A]/10 text-[#1A1A1A]/70 hover:text-brand-gold hover:border-[#1A1A1A]/30'
                  }`}
                >
                  <TabIcon className="w-4 h-4 shrink-0" />
                  <span className="truncate">{prog.name.split(' & ')[0]}</span>
                </button>
              );
            })}
          </div>

          {/* Active Tab Content Render (Right 3 Columns) */}
          <div className="lg:col-span-3">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.3 }}
                className="bg-[#FDFBF7] rounded-none p-6 sm:p-8 lg:p-10 border border-[#1A1A1A]/10 shadow-sm grid grid-cols-1 md:grid-cols-12 gap-8"
              >
                {/* Details Section */}
                <div className="md:col-span-7 space-y-6 flex flex-col justify-between">
                  <div>
                    {/* Header Details */}
                    <div className="flex items-center gap-3 text-brand-gold mb-3.5">
                      <ActiveIconComp className="w-7 h-7 p-1 bg-brand-gold/10 border border-brand-gold/20" />
                      <span className="font-sans text-xs uppercase tracking-widest font-extrabold">
                        {activeProgram.tagline}
                      </span>
                    </div>

                    <h3 className="font-serif text-2xl sm:text-3xl font-black text-[#1A1A1A] mb-3">
                      {activeProgram.name}
                    </h3>
                    
                    <p className="font-sans text-sm text-[#1A1A1A]/80 font-light leading-relaxed">
                      {activeProgram.description}
                    </p>
                  </div>

                  {/* Program Metadata Spec Grid */}
                  <div className="grid grid-cols-2 gap-4 border-y border-[#1A1A1A]/10 py-5 my-4">
                    <div>
                      <span className="block text-[9px] uppercase font-bold tracking-widest text-[#1A1A1A]/50 mb-0.5">
                        Target Group
                      </span>
                      <span className="font-sans text-xs font-bold text-[#1A1A1A]">
                        {activeProgram.ageGroup}
                      </span>
                    </div>
                    <div>
                      <span className="block text-[9px] uppercase font-bold tracking-widest text-[#1A1A1A]/50 mb-0.5">
                        Format / Duration
                      </span>
                      <span className="font-sans text-xs font-bold text-[#1A1A1A]">
                        {activeProgram.durationLevel}
                      </span>
                    </div>
                    <div>
                      <span className="block text-[9px] uppercase font-bold tracking-widest text-[#1A1A1A]/50 mb-0.5">
                        Standard Fee
                      </span>
                      <span className="font-sans text-xs font-extrabold text-brand-gold">
                        {activeProgram.priceLabel}
                      </span>
                    </div>
                    <div>
                      <span className="block text-[9px] uppercase font-bold tracking-widest text-[#1A1A1A]/50 mb-0.5">
                        Trial Option
                      </span>
                      <span className="font-sans text-[10px] font-bold text-emerald-800 bg-emerald-500/10 px-2.5 py-0.5 rounded border border-emerald-500/20 inline-block w-fit">
                        {activeProgram.trialPrice}
                      </span>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-2">
                    <button
                      onClick={() => handleQuickBook(activeProgram.id)}
                      className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-none font-sans text-xs font-bold uppercase tracking-widest text-[#FDFBF7] bg-[#1A1A1A] hover:bg-brand-gold hover:text-white transition-all duration-300 shadow cursor-pointer"
                    >
                      Instant Book Free Trial
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                    <a
                      href="#booking"
                      onClick={() => onSelectInstrument(activeProgram.id)}
                      className="text-center px-4 py-3 text-xs font-bold uppercase tracking-widest text-[#1A1A1A]/60 hover:text-brand-gold transition-colors"
                    >
                      Inquire Details
                    </a>
                  </div>
                </div>

                {/* Checklist & Image Frame */}
                <div className="md:col-span-5 flex flex-col justify-between gap-6">
                  {/* Photo Thumbnail */}
                  <div className="w-full aspect-[16/10] sm:aspect-[16/9] md:aspect-[4/3] rounded-none overflow-hidden border border-[#1A1A1A]/10">
                    <img
                      src={activeProgram.image}
                      alt={activeProgram.name}
                      className="w-full h-full object-cover select-none filter brightness-100"
                      referrerPolicy="no-referrer"
                    />
                  </div>

                  {/* Syllabus Checklist */}
                  <div className="bg-[#FAF6F0] border border-[#1A1A1A]/10 rounded-none p-4 sm:p-5">
                    <h4 className="font-sans text-xs font-bold uppercase tracking-widest text-brand-gold mb-3.5">
                      Curriculum Highlights
                    </h4>
                    <ul className="space-y-3">
                      {activeProgram.syllabusOverview.map((item, index) => (
                        <li key={index} className="flex items-start gap-2 text-xs font-sans text-[#1A1A1A]/80">
                          <CheckCircle2 className="w-4 h-4 text-brand-gold shrink-0 mt-0.5" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

              </motion.div>
            </AnimatePresence>
          </div>

        </div>

      </div>
    </section>
  );
}
