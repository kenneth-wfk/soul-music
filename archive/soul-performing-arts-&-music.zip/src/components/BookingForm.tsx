import { useState, useEffect, FormEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Booking } from '../types';
import { MUSIC_PROGRAMS } from '../data';
import { Calendar, Clock, Phone, User, BookOpen, AlertCircle, Sparkles, CheckCircle, Trash2, Facebook, MessageSquare, Ticket } from 'lucide-react';

interface BookingFormProps {
  selectedInstrumentId: string;
  onClearSelectedInstrument: () => void;
  isSpiritDiscountApplied: boolean;
}

export default function BookingForm({
  selectedInstrumentId,
  onClearSelectedInstrument,
  isSpiritDiscountApplied
}: BookingFormProps) {
  // Local state for list of bookings saved in localStorage
  const [myBookings, setMyBookings] = useState<Booking[]>([]);
  
  // Active Form States
  const [formData, setFormData] = useState({
    studentName: '',
    studentAge: '',
    instrument: '',
    skillLevel: 'Beginner' as 'Beginner' | 'Intermediate' | 'Advanced',
    preferredDay: 'Saturday',
    preferredTime: 'Afternoon (2:00 PM - 5:00 PM)',
    contactWhatsApp: '',
    specialInstructions: ''
  });

  // Errors state
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  // Successful checkout ticket
  const [activeTicket, setActiveTicket] = useState<Booking | null>(null);

  // Sync selected instrument from parent
  useEffect(() => {
    if (selectedInstrumentId) {
      setFormData((prev) => ({ ...prev, instrument: selectedInstrumentId }));
    }
  }, [selectedInstrumentId]);

  // Load bookings from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem('soul_school_bookings');
    if (saved) {
      try {
        setMyBookings(JSON.parse(saved));
      } catch (e) {
        console.error('Failed to parse saved bookings', e);
      }
    }
  }, []);

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.studentName.trim()) {
      newErrors.studentName = 'Full name is required.';
    }
    if (!formData.instrument) {
      newErrors.instrument = 'Please pick a course of interest.';
    }
    const phoneRegex = /^[0-9+()-\s]{8,18}$/;
    if (!formData.contactWhatsApp.trim() || !phoneRegex.test(formData.contactWhatsApp)) {
      newErrors.contactWhatsApp = 'Please enter a valid phone number (WhatsApp compatible).';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    // Create unique enquiry code
    const ticketNum = Math.floor(100000 + Math.random() * 900000);
    const code = `SOUL-ENQ-${ticketNum}`;
    
    // Find program display name
    const progObj = MUSIC_PROGRAMS.find((p) => p.id === formData.instrument);
    const instrumentName = progObj ? progObj.name : formData.instrument;

    const newBooking: Booking = {
      id: Date.now().toString(),
      studentName: formData.studentName,
      studentAge: 18, // generic default for booking representation compliance
      instrument: instrumentName,
      skillLevel: formData.skillLevel,
      preferredDay: 'Pending team reply',
      preferredTime: 'Pending Team follow-up',
      contactWhatsApp: formData.contactWhatsApp,
      specialInstructions: formData.specialInstructions,
      bookingDate: new Date().toLocaleDateString('en-GB'),
      status: 'Received',
      ticketCode: code,
      spiritDiscountApplied: isSpiritDiscountApplied
    };

    const updated = [newBooking, ...myBookings];
    setMyBookings(updated);
    localStorage.setItem('soul_school_bookings', JSON.stringify(updated));
    
    // Set response ticket to showcase success screen
    setActiveTicket(newBooking);

    // Reset Form
    setFormData({
      studentName: '',
      studentAge: '',
      instrument: '',
      skillLevel: 'Beginner',
      preferredDay: 'Saturday',
      preferredTime: 'Afternoon (2:00 PM - 5:00 PM)',
      contactWhatsApp: '',
      specialInstructions: ''
    });
    onClearSelectedInstrument();
  };

  const handleCancelBooking = (id: string) => {
    const filtered = myBookings.filter((b) => b.id !== id);
    setMyBookings(filtered);
    localStorage.setItem('soul_school_bookings', JSON.stringify(filtered));
  };

  return (
    <section id="booking" className="py-24 bg-[#FAF6F0] relative border-b border-[#1A1A1A]/10">
      
      {/* Visual glowing blob */}
      <div className="absolute left-1/2 -translate-x-1/2 top-10 w-96 h-96 rounded-full bg-brand-gold/5 blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header Block */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-4">
          <span className="text-xs uppercase font-extrabold tracking-[0.25em] text-brand-gold">
            Quick Enquiry
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl font-black text-[#1A1A1A] uppercase tracking-tight">
            Ask Puan Sarah & Crew
          </h2>
          <div className="w-16 h-0.5 bg-brand-gold mx-auto" />
          <p className="font-sans text-[#1A1A1A]/70 font-light text-sm sm:text-base">
            Have questions about fees, syllabus, class timings, or customized pathways? Submit your message, and we will reply directly on WhatsApp.
          </p>
        </div>

        {/* Layout Partition: Left Form or success ticket, Right list of bookings */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Main Workspace (Left 7/8 columns) */}
          <div className="lg:col-span-8 bg-[#FDFBF7] rounded-none p-6 sm:p-8 border border-[#1A1A1A]/10 shadow-sm min-h-[500px] flex flex-col justify-center">
            
            <AnimatePresence mode="wait">
              
              {/* Success Ticket Screen */}
              {activeTicket ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.98 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.98 }}
                  transition={{ duration: 0.4 }}
                  className="space-y-6 text-center"
                >
                  <div className="w-14 h-14 rounded-none bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center mx-auto text-emerald-800 shadow-sm">
                    <CheckCircle className="w-7 h-7" />
                  </div>

                  <div className="space-y-2">
                    <h3 className="font-serif text-2xl font-black text-[#1A1A1A] uppercase tracking-tight">
                      Enquiry Submitted!
                    </h3>
                    <p className="font-sans text-sm text-[#1A1A1A]/80 max-w-lg mx-auto font-light leading-relaxed">
                      Your enquiry has been successfully logged. Puan Sarah & the admin crew will notify your WhatsApp contact within <strong>4 to 12 working hours</strong>.
                    </p>
                  </div>

                  {/* Physical Style Boarding Ticket */}
                  <div className="max-w-md mx-auto bg-[#FAF6F0] border-2 border-[#1A1A1A] rounded-none overflow-hidden shadow-sm relative">
                    <div className="absolute top-1/2 -left-3 w-6 h-6 rounded-full bg-[#FDFBF7] border-r border-[#1A1A1A] -translate-y-1/2" />
                    <div className="absolute top-1/2 -right-3 w-6 h-6 rounded-full bg-[#FDFBF7] border-l border-[#1A1A1A] -translate-y-1/2" />
                    
                    {/* Ticket Header */}
                    <div className="bg-brand-gold/10 border-b border-[#1A1A1A]/10 p-4 flex items-center justify-between">
                      <div className="text-left">
                        <span className="block text-[8px] uppercase font-extrabold tracking-widest text-[#aa8d65] text-brand-gold">
                          Academy Enquiry Ticket
                        </span>
                        <span className="font-serif text-sm font-black text-[#1A1A1A] tracking-wide">
                          SOUL PERFORMING ARTS
                        </span>
                      </div>
                      <Ticket className="w-6 h-6 text-brand-gold animate-pulse" />
                    </div>

                    {/* Ticket Body Details */}
                    <div className="p-5 grid grid-cols-2 gap-4 text-left font-sans text-xs sm:text-sm">
                      <div className="space-y-0.5 col-span-1">
                        <span className="block text-[9px] uppercase tracking-wider font-bold text-[#1A1A1A]/40">Your Name</span>
                        <span className="block font-bold text-[#1A1A1A] truncate">{activeTicket.studentName}</span>
                      </div>
                      <div className="space-y-0.5 col-span-1">
                        <span className="block text-[9px] uppercase tracking-wider font-bold text-[#1A1A1A]/40">WhatsApp Contact</span>
                        <span className="block font-bold text-[#1A1A1A]">{activeTicket.contactWhatsApp}</span>
                      </div>
                      <div className="space-y-0.5 col-span-1">
                        <span className="block text-[9px] uppercase tracking-wider font-bold text-[#1A1A1A]/40">Selected Course</span>
                        <span className="block font-bold text-brand-gold truncate">{activeTicket.instrument}</span>
                      </div>
                      <div className="space-y-0.5 col-span-1">
                        <span className="block text-[9px] uppercase tracking-wider font-bold text-[#1A1A1A]/40">Date Submitted</span>
                        <span className="block font-bold text-[#1A1A1A]">{activeTicket.bookingDate}</span>
                      </div>
                      <div className="space-y-0.5 col-span-2">
                        <span className="block text-[9px] uppercase tracking-wider font-bold text-[#1A1A1A]/40">Your Message / Questions</span>
                        <p className="font-sans text-xs italic text-[#1A1A1A]/85 font-normal leading-relaxed line-clamp-3">
                          "{activeTicket.specialInstructions || "No additional message details entered."}"
                        </p>
                      </div>
                      <div className="space-y-1 col-span-2 pt-2 border-t border-[#1A1A1A]/10 flex items-center justify-between">
                        <div>
                          <span className="block text-[9px] uppercase tracking-wider font-bold text-[#1A1A1A]/40">Ticket Code</span>
                          <span className="block font-mono text-xs font-bold text-[#1A1A1A] uppercase select-all bg-[#1A1A1A]/5 px-2.5 py-0.5 rounded-none border border-[#1A1A1A]/15">{activeTicket.ticketCode}</span>
                        </div>
                        {activeTicket.spiritDiscountApplied && (
                          <div className="text-right">
                            <span className="inline-block text-[9px] uppercase font-bold text-emerald-800 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-0.5 rounded-none">
                              10% Quiz Off Match
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Faster Pathway Check Call-to-action */}
                  <div className="space-y-4 pt-4 max-w-md mx-auto">
                    <p className="font-sans text-xs text-[#1A1A1A]/60">
                      Want to expedite your reply instantly? Click below to send your Enquiry Ticket code directly to our Messenger admins!
                    </p>
                    <div className="flex flex-col sm:flex-row gap-3">
                      <a
                        href={`https://www.facebook.com/soulperformingmusic`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex-1 inline-flex items-center justify-center gap-2 px-6 py-3 border border-[#1A1A1A] text-[#1A1A1A] hover:bg-[#1A1A1A] hover:text-[#FDFBF7] font-bold rounded-none text-xs uppercase tracking-widest transition-all duration-200"
                      >
                        <Facebook className="w-4 h-4 fill-current" />
                        <span>Facebook Live Chat</span>
                      </a>
                      <button
                        onClick={() => setActiveTicket(null)}
                        className="flex-1 inline-flex items-center justify-center gap-2 px-6 py-3 bg-brand-gold hover:bg-[#1A1A1A] text-white font-bold rounded-none text-xs uppercase tracking-widest transition-all duration-200 border border-brand-gold hover:border-[#1A1A1A]"
                      >
                        <span>Send Another Enquiry</span>
                      </button>
                    </div>
                  </div>

                </motion.div>
              ) : (
                
                // Form Interface
                <motion.form
                  key="booking-form"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  onSubmit={handleSubmit}
                  className="space-y-5"
                >
                  <div className="flex items-center justify-between pb-3 border-b border-[#1A1A1A]/10">
                    <h3 className="font-serif text-lg font-black text-[#1A1A1A] uppercase tracking-wider flex items-center gap-2">
                      <Sparkles className="w-4.5 h-4.5 text-brand-gold" />
                      <span>Enquiry Board</span>
                    </h3>
                    {isSpiritDiscountApplied && (
                      <span className="font-sans text-[10px] font-bold text-emerald-800 bg-emerald-500/10 px-2.5 py-1 rounded-none border border-emerald-500/20 inline-flex items-center gap-1">
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>10% Assessment Code Applied</span>
                      </span>
                    )}
                  </div>

                  <div className="space-y-5">
                    
                    {/* Student Name */}
                    <div className="space-y-1.5 text-left">
                      <label className="block text-xs uppercase tracking-wider font-extrabold text-[#1A1A1A]/60 flex items-center gap-1">
                        <User className="w-3.5 h-3.5 text-brand-gold" />
                        <span>Your Full Name *</span>
                      </label>
                      <input
                        type="text"
                        name="studentName"
                        value={formData.studentName}
                        onChange={(e) => setFormData((p) => ({ ...p, studentName: e.target.value }))}
                        placeholder="e.g. Rachel Lim Wei Wey"
                        className="w-full bg-[#FAF6F0] hover:bg-white border border-[#1A1A1A]/15 focus:border-brand-gold text-[#1A1A1A] font-sans text-xs uppercase tracking-wider font-bold rounded-none px-4 py-3 outline-none transition-all placeholder-[#1A1A1A]/30"
                      />
                      {errors.studentName && (
                        <p className="text-rose-600 text-[11px] flex items-center gap-1">
                          <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                          <span>{errors.studentName}</span>
                        </p>
                      )}
                    </div>

                    {/* WhatsApp contact */}
                    <div className="space-y-1.5 text-left">
                      <label className="block text-xs uppercase tracking-wider font-extrabold text-[#1A1A1A]/60 flex items-center gap-1">
                        <Phone className="w-3.5 h-3.5 text-brand-gold" />
                        <span>WhatsApp Contact Number *</span>
                      </label>
                      <input
                        type="tel"
                        name="contactWhatsApp"
                        value={formData.contactWhatsApp}
                        onChange={(e) => setFormData((p) => ({ ...p, contactWhatsApp: e.target.value }))}
                        placeholder="e.g. +60 12-345 6789"
                        className="w-full bg-[#FAF6F0] hover:bg-white border border-[#1A1A1A]/15 focus:border-brand-gold text-[#1A1A1A] font-sans text-xs uppercase tracking-wider font-bold rounded-none px-4 py-3 outline-none transition-all placeholder-[#1A1A1A]/30"
                      />
                      {errors.contactWhatsApp && (
                        <p className="text-rose-600 text-[11px] flex items-center gap-1">
                          <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                          <span>{errors.contactWhatsApp}</span>
                        </p>
                      )}
                    </div>

                    {/* Select Instrument */}
                    <div className="space-y-1.5 text-left">
                      <label className="block text-xs uppercase tracking-wider font-extrabold text-[#1A1A1A]/60 flex items-center gap-1">
                        <BookOpen className="w-3.5 h-3.5 text-brand-gold" />
                        <span>Select Musical Course of Interest *</span>
                      </label>
                      <select
                        name="instrument"
                        value={formData.instrument}
                        onChange={(e) => setFormData((p) => ({ ...p, instrument: e.target.value }))}
                        className="w-full bg-[#FAF6F0] hover:bg-white border border-[#1A1A1A]/15 focus:border-brand-gold text-[#1A1A1A] font-sans text-xs uppercase tracking-wider font-bold rounded-none px-4 py-3 outline-none transition-all"
                      >
                        <option value="">-- Choose Course --</option>
                        {MUSIC_PROGRAMS.map((item) => (
                          <option key={item.id} value={item.id}>
                            {item.name} ({item.ageGroup})
                          </option>
                        ))}
                      </select>
                      {errors.instrument && (
                        <p className="text-rose-600 text-[11px] flex items-center gap-1">
                          <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                          <span>{errors.instrument}</span>
                        </p>
                      )}
                    </div>

                    {/* Inquiry Message text */}
                    <div className="space-y-1.5 text-left">
                      <label className="block text-xs uppercase tracking-wider font-extrabold text-[#1A1A1A]/60">
                        Inquiry message / Ask us about anything (scheduling, fees, teacher matching)
                      </label>
                      <textarea
                        rows={4}
                        name="specialInstructions"
                        value={formData.specialInstructions}
                        onChange={(e) => setFormData((p) => ({ ...p, specialInstructions: e.target.value }))}
                        placeholder="e.g. Hi! I'm enquiring about weekend piano slots for my 6-year-old child. What are the monthly fees?"
                        className="w-full bg-[#FAF6F0] hover:bg-white border border-[#1A1A1A]/15 focus:border-brand-gold text-[#1A1A1A] font-sans text-xs uppercase tracking-wider font-bold rounded-none px-4 py-3 outline-none transition-all resize-none placeholder-[#1A1A1A]/30"
                      />
                    </div>

                  </div>

                  {/* Submission Row */}
                  <div className="pt-4 text-left">
                    <button
                      type="submit"
                      className="w-full py-4 text-center text-xs font-bold uppercase tracking-widest text-[#FDFBF7] bg-[#1A1A1A] hover:bg-brand-gold rounded-none border border-[#1A1A1A] hover:border-brand-gold transition-all duration-300 shadow cursor-pointer"
                    >
                      Submit Enquiry Ticket
                    </button>
                    <p className="text-center text-[10px] text-[#1A1A1A]/50 mt-3 font-sans">
                      By submitting, you consent to receive a WhatsApp follow-up with complete answers, brochures, and free trial scheduling if desired.
                    </p>
                  </div>

                </motion.form>
              )}
            </AnimatePresence>
          </div>

          {/* Local Schedule Database (Right 4 columns) */}
          <div className="lg:col-span-4 bg-[#FAF6F0]/60 border border-[#1A1A1A]/10 rounded-none p-5 sm:p-6 space-y-5 shadow-sm">
            <h4 className="font-serif text-sm font-black text-[#1A1A1A] uppercase tracking-wider flex items-center gap-2">
              <MessageSquare className="w-4.5 h-4.5 text-brand-gold" />
              <span>My Enquiries ({myBookings.length})</span>
            </h4>
            
            <AnimatePresence initial={false}>
              {myBookings.length === 0 ? (
                <motion.div
                  key="no-bookings"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="py-12 text-center text-[#1A1A1A]/50 text-xs font-sans space-y-1 border border-dashed border-[#1A1A1A]/15 rounded-none"
                >
                  <p>No enquiries submitted yet.</p>
                  <p className="text-[10px] text-[#1A1A1A]/40">Your submitted enquiries will display here locally for your record.</p>
                </motion.div>
              ) : (
                <div className="space-y-3.5 max-h-[480px] overflow-y-auto pr-1">
                  {myBookings.map((b) => (
                    <motion.div
                      key={b.id}
                      initial={{ scale: 0.95, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      exit={{ scale: 0.95, opacity: 0 }}
                      className="bg-[#FDFBF7] border border-[#1A1A1A]/10 hover:border-brand-gold/30 rounded-none p-4 text-left text-xs space-y-2.5 relative group shadow-sm transition-all duration-300"
                    >
                      <button
                        onClick={() => handleCancelBooking(b.id)}
                        className="absolute top-3.5 right-3.5 p-1 text-[#1A1A1A]/40 hover:text-rose-600 rounded transition-colors"
                        title="Cancel Request"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>

                      <div className="space-y-0.5">
                        <span className="block text-[8px] font-mono text-brand-gold font-bold uppercase">{b.ticketCode}</span>
                        <h5 className="font-sans font-extrabold text-[#1A1A1A] pr-6 truncate">{b.studentName}</h5>
                      </div>

                      <div className="grid grid-cols-2 gap-y-1.5 text-[11px] text-[#1A1A1A]/60 font-sans">
                        <div>
                          <span className="block text-[8px] text-[#1A1A1A]/40 uppercase font-bold tracking-wider">Course</span>
                          <span className="text-[#1A1A1A]/80 font-bold truncate block max-w-[100px]">{b.instrument}</span>
                        </div>
                        <div>
                          <span className="block text-[8px] text-[#1A1A1A]/40 uppercase font-bold tracking-wider">Date</span>
                          <span className="text-[#1A1A1A]/80 font-bold">{b.bookingDate}</span>
                        </div>
                        <div>
                          <span className="block text-[8px] text-[#1A1A1A]/40 uppercase font-bold tracking-wider">WhatsApp</span>
                          <span className="text-[#1A1A1A]/80 font-mono truncate block max-w-[100px]">{b.contactWhatsApp}</span>
                        </div>
                        <div>
                          <span className="block text-[8px] text-[#1A1A1A]/40 uppercase font-bold tracking-wider">Status</span>
                          <span className="inline-block text-[9px] px-2 py-0.5 bg-brand-gold/10 text-brand-gold font-extrabold rounded-none uppercase scale-90 -translate-x-1">
                            {b.status}
                          </span>
                        </div>
                      </div>

                    </motion.div>
                  ))}
                </div>
              )}
            </AnimatePresence>

            <div className="pt-2">
              <a
                href="https://www.facebook.com/soulperformingmusic"
                target="_blank"
                rel="noopener noreferrer"
                className="w-full flex items-center justify-center gap-2 py-2.5 bg-[#1877F2]/5 hover:bg-[#1877F2]/10 border border-[#1877F2]/15 text-[#1877F2] font-semibold text-xs uppercase tracking-widest rounded-none transition-all"
              >
                <Facebook className="w-4 h-4 fill-[#1877F2] text-[#1877F2]" />
                <span>Visit FB Community</span>
              </a>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
