import { motion } from 'motion/react';
import { ArrowRight, Music, Sparkles, Award, Star } from 'lucide-react';

export default function Hero() {
  return (
    <section
      id="hero"
      className="relative min-h-screen bg-[#FDFBF7] pt-32 pb-24 md:pb-32 flex items-center justify-center overflow-hidden border-b border-[#1A1A1A]/10"
    >
      {/* Visual Background Decors */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-radial-at-t from-[#FAF6F0] via-[#FDFBF7] to-[#FDFBF7] opacity-98" />
        <div 
          className="absolute inset-0 opacity-5 mix-blend-multiply"
          style={{
            backgroundImage: "url('https://images.unsplash.com/photo-1511192336575-5a79af67a629?q=80&w=1600&auto=format&fit=crop')",
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        />
        {/* Soft glowing ambient rings */}
        <div className="absolute top-1/4 left-1/4 w-[400px] h-[400px] rounded-full bg-brand-gold/5 blur-[80px]" />
        <div className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] rounded-full bg-brand-gold/5 blur-[100px]" />
      </div>

      {/* Decorative vertical-text ribbon */}
      <div className="absolute left-6 top-1/2 -translate-y-1/2 [writing-mode:vertical-rl] rotate-180 text-[10px] uppercase tracking-[0.5em] text-[#1A1A1A]/30 font-bold hidden xl:block select-none">
        Est. 2012 — Performing Arts Excellence
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Main Hero Copy (Left 7 Columns) */}
          <div className="lg:col-span-7 space-y-6 md:space-y-8 text-center lg:text-left">
            
            {/* Live Enrollment Status Indicator */}
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-brand-gold/10 border border-brand-gold/20 text-brand-gold text-xs sm:text-sm font-bold tracking-widest uppercase mx-auto lg:mx-0"
            >
              <Sparkles className="w-4 h-4 text-brand-gold animate-pulse" />
              <span>Now Enrolling For 2026/2027 Terms</span>
            </motion.div>

            {/* Giant Title */}
            <div className="space-y-2 md:space-y-3">
              <motion.h1
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.1 }}
                className="font-serif text-5xl sm:text-6xl lg:text-7xl font-black text-[#1A1A1A] tracking-tighter leading-[1.0] uppercase"
              >
                Where Passion <br className="hidden sm:inline" />
                Meets <span className="text-brand-gold italic font-normal">Performance</span>
              </motion.h1>
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="font-sans text-sm sm:text-base text-[#1A1A1A]/80 max-w-xl mx-auto lg:mx-0 font-light leading-relaxed"
              >
                Unleash your inner rhythm at <span className="text-[#1A1A1A] font-bold text-brand-gold/90 border-b border-brand-gold/20">Soul Performing Arts & Music</span>. 
                Based in Kampar, Perak, Malaysia, we provide professional 1-on-1 and group music lessons custom-styled to every age and skill benchmark.
              </motion.p>
            </div>

            {/* Hero Actions */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4"
            >
              <a
                href="#booking"
                className="w-full sm:w-auto text-center px-8 py-4 font-sans font-bold text-xs uppercase tracking-widest text-[#FDFBF7] bg-[#1A1A1A] hover:bg-transparent border border-[#1A1A1A] hover:text-[#1A1A1A] transition-colors duration-300 shadow-sm"
              >
                Book Your Free 30-Min Trial
              </a>
              <a
                href="#programs"
                className="w-full sm:w-auto text-center px-8 py-4 font-sans font-bold text-xs uppercase tracking-widest text-[#1A1A1A] hover:bg-[#1A1A1A] hover:text-white border border-[#1A1A1A] transition-colors duration-300 flex items-center justify-center gap-2 group"
              >
                Explore Programs
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </a>
            </motion.div>

            {/* Micro badges */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.5 }}
              className="grid grid-cols-3 gap-3 md:gap-4 max-w-md md:max-w-xl mx-auto lg:mx-0 pt-6 border-t border-[#1A1A1A]/10"
            >
              <div className="text-center lg:text-left">
                <span className="block font-serif text-2xl md:text-3xl font-black text-brand-gold italic">100%</span>
                <span className="block text-[9px] text-[#1A1A1A]/60 uppercase tracking-widest font-extrabold mt-1">
                  ABRSM Exam Pass
                </span>
              </div>
              <div className="text-center lg:text-left border-x border-[#1A1A1A]/10 px-2 sm:px-4">
                <span className="block font-serif text-2xl md:text-3xl font-black text-brand-gold italic">1-on-1</span>
                <span className="block text-[9px] text-[#1A1A1A]/60 uppercase tracking-widest font-extrabold mt-1">
                  Individual Fit
                </span>
              </div>
              <div className="text-center lg:text-left">
                <span className="block font-serif text-2xl md:text-3xl font-black text-brand-gold italic">Ages 3+</span>
                <span className="block text-[9px] text-[#1A1A1A]/60 uppercase tracking-widest font-extrabold mt-1">
                  Toddlers to Adults
                </span>
              </div>
            </motion.div>
          </div>

          {/* Graphical Frame (Right 5 Columns) */}
          <div className="lg:col-span-5 relative mt-6 lg:mt-0 flex justify-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, rotateY: 10 }}
              animate={{ opacity: 1, scale: 1, rotateY: 0 }}
              transition={{ duration: 0.8 }}
              className="relative w-full max-w-[420px] aspect-[4/5] rounded-3xl overflow-hidden group shadow-lg border border-[#1A1A1A]/10"
            >
              {/* Foreground Image */}
              <img
                src="https://images.unsplash.com/photo-1484876065684-b683cf17d276?q=80&w=600&auto=format&fit=crop"
                alt="Soul Performing Arts & Music performance spotlight"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 select-none brightness-100 relative"
                referrerPolicy="no-referrer"
              />

              {/* Decorative Card Embedded */}
              <div className="absolute inset-x-4 bottom-4 p-5 rounded-2xl bg-[#FDFBF7]/95 backdrop-blur-md border border-[#1A1A1A]/10 flex flex-col gap-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-brand-gold">
                    <Star className="w-3.5 h-3.5 fill-brand-gold text-brand-gold" />
                    <Star className="w-3.5 h-3.5 fill-brand-gold text-brand-gold" />
                    <Star className="w-3.5 h-3.5 fill-brand-gold text-brand-gold" />
                    <Star className="w-3.5 h-3.5 fill-brand-gold text-brand-gold" />
                    <Star className="w-3.5 h-3.5 fill-brand-gold text-brand-gold" />
                  </div>
                  <span className="text-[9px] font-sans font-bold text-brand-gold bg-brand-gold/10 px-2 py-0.5 rounded border border-brand-gold/20 uppercase tracking-wider">
                    Kampar, Perak
                  </span>
                </div>
                <p className="text-xs font-sans text-[#1A1A1A]/80 leading-relaxed italic text-left">
                  "The positive energy is instantly contagious here. The teachers don't just instruct; they truly care about individual musical growth."
                </p>
                <div className="flex items-center gap-2 pt-1.5 border-t border-[#1A1A1A]/5 mt-1">
                  <div className="w-6 h-6 rounded-full bg-brand-gold text-white flex items-center justify-center font-serif text-[9px] font-bold">
                    SPA
                  </div>
                  <div className="text-left">
                    <h4 className="text-[11px] font-sans font-bold text-[#1A1A1A] leading-none">Chua Yee Wey</h4>
                    <span className="text-[9px] text-[#1A1A1A]/50">Adult Piano Community</span>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>

        </div>
      </div>
    </section>
  );
}
