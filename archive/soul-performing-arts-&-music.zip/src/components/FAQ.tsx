import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { FAQS } from '../data';
import { HelpCircle, ChevronDown } from 'lucide-react';

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleAccordion = (index: number) => {
    if (openIndex === index) {
      setOpenIndex(null);
    } else {
      setOpenIndex(index);
    }
  };

  return (
    <section id="faq" className="py-24 bg-[#FAF6F0] relative border-b border-[#1A1A1A]/10">
      
      {/* Visual glowing blob */}
      <div className="absolute left-1/4 bottom-10 w-64 h-64 rounded-full bg-brand-gold/5 blur-[90px] pointer-events-none" />

      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        
        {/* Header Block */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-4">
          <span className="text-xs uppercase font-extrabold tracking-[0.25em] text-brand-gold">
            FAQ Desk
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl font-black text-[#1A1A1A] uppercase tracking-tight">
            Common Inquiries
          </h2>
          <div className="w-16 h-0.5 bg-brand-gold mx-auto" />
          <p className="font-sans text-[#1A1A1A]/70 font-light text-sm sm:text-base">
            Everything you need to know about setting up your first class, scheduling priorities, make-ups, and syllabus pacing.
          </p>
        </div>

        {/* Accordion list */}
        <div className="space-y-4">
          {FAQS.map((faq, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div
                key={idx}
                className="bg-[#FDFBF7] border border-[#1A1A1A]/10 rounded-none overflow-hidden transition-all duration-300"
              >
                <button
                  type="button"
                  onClick={() => toggleAccordion(idx)}
                  className="w-full text-left px-5 py-4 sm:py-5 flex items-center justify-between gap-4 focus:outline-none focus:ring-1 focus:ring-[#1A1A1A]/5 cursor-pointer select-none"
                >
                  <div className="flex items-center gap-3">
                    <HelpCircle className="w-5 h-5 text-brand-gold shrink-0" />
                    <span className="font-sans text-sm sm:text-base font-bold text-[#1A1A1A] tracking-wide">
                      {faq.question}
                    </span>
                  </div>
                  <ChevronDown
                    className={`w-5 h-5 text-[#1A1A1A]/40 hover:text-brand-gold transition-transform duration-300 shrink-0 ${
                      isOpen ? 'rotate-180 text-brand-gold' : ''
                    }`}
                  />
                </button>

                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.25, ease: 'easeInOut' }}
                    >
                      <div className="px-5 pb-5 sm:pb-6 pt-1">
                        <p className="font-sans text-xs sm:text-sm text-[#1A1A1A]/75 font-normal leading-relaxed pl-8 border-l border-brand-gold">
                          {faq.answer}
                        </p>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
