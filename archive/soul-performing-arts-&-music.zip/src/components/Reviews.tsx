import { TESTIMONIALS } from '../data';
import { Star, MessageSquare } from 'lucide-react';

export default function Reviews() {
  return (
    <section id="testimonials" className="py-24 bg-[#FDFBF7] relative border-b border-[#1A1A1A]/10">
      
      {/* Decorative Blur */}
      <div className="absolute left-10 top-1/4 w-80 h-80 rounded-full bg-brand-gold/5 blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header Block */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-4">
          <span className="text-xs uppercase font-extrabold tracking-[0.25em] text-brand-gold">
            Success Highlights
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl font-black text-[#1A1A1A] uppercase tracking-tight">
            Sound Stories
          </h2>
          <div className="w-16 h-0.5 bg-brand-gold mx-auto" />
          <p className="font-sans text-[#1A1A1A]/70 font-light text-sm sm:text-base">
            Read direct stories from our parents, adult learners, and alumni in Malaysia who have unlocked high self-confidence and exam success.
          </p>
        </div>

        {/* Testimonials Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {TESTIMONIALS.map((review, rIdx) => {
            return (
              <div
                key={review.id}
                className="flex flex-col justify-between p-6 sm:p-8 rounded-none border border-[#1A1A1A]/10 bg-[#FAF6F0] relative overflow-hidden shadow-sm hover:border-brand-gold/30 transition-all duration-300 md:col-span-1"
              >
                {/* Decorative floating top icon */}
                <div className="absolute top-6 right-6 opacity-[0.04]">
                  <MessageSquare className="w-16 h-16 text-[#1A1A1A]" />
                </div>

                <div className="space-y-4">
                  {/* Rating Stars */}
                  <div className="flex items-center gap-1.5 text-brand-gold">
                    {Array.from({ length: review.rating }).map((_, s) => (
                      <Star key={s} className="w-4 h-4 fill-brand-gold text-brand-gold" />
                    ))}
                  </div>

                  {/* Core Testimonial Copy */}
                  <p className="font-serif text-sm sm:text-base text-[#1A1A1A]/95 font-medium leading-relaxed italic text-left relative z-10">
                    "{review.content}"
                  </p>
                </div>

                {/* Patient Signature Details */}
                <div className="flex items-center gap-3 pt-5 border-t border-[#1A1A1A]/15 mt-6 relative z-10">
                  <div className="w-10 h-10 rounded-none bg-[#1A1A1A] flex items-center justify-center font-serif text-[11px] font-black text-white select-none uppercase shrink-0">
                    {review.avatarId}
                  </div>
                  <div className="space-y-0.5 text-left truncate">
                    <h4 className="font-sans text-sm font-bold text-[#1A1A1A] leading-tight truncate">
                      {review.author}
                    </h4>
                    <span className="block text-[10px] sm:text-xs text-[#1A1A1A]/60">
                      {review.relation}
                    </span>
                  </div>
                </div>

              </div>
            );
          })}
        </div>

        {/* Facebook Page Review Engagement Call-to-action */}
        <div className="mt-12 text-center rounded-none bg-[#FAF6F0] border border-[#1A1A1A]/10 p-5 max-w-2xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="font-sans text-xs sm:text-sm text-[#1A1A1A]/75 font-normal text-left">
            Have you been a part of the <strong>Soul Performing Arts & Music</strong> family? Write a review on our official Facebook Page to inspire other musical seekers!
          </p>
          <a
            href="https://www.facebook.com/soulperformingmusic/reviews"
            target="_blank"
            rel="noopener noreferrer"
            className="px-5 py-2.5 bg-[#1A1A1A] hover:bg-brand-gold text-white hover:text-[#FAF6F0] text-xs font-bold uppercase tracking-wider rounded-none transition-all duration-200 shrink-0 text-center w-full sm:w-auto"
          >
            Leave Facebook Review
          </a>
        </div>

      </div>
    </section>
  );
}
