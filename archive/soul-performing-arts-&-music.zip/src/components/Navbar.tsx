import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Music, Menu, X, Facebook, ExternalLink } from 'lucide-react';

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Monitor scroll height
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const menuItems = [
    { label: 'Programs', href: '#programs' },
    { label: 'Find Your Sound', href: '#sound-quiz' },
    { label: 'Mentors', href: '#mentors' },
    { label: 'Testimonials', href: '#testimonials' },
    { label: 'FAQ', href: '#faq' },
    { label: 'Location', href: '#location' },
  ];

  return (
    <>
      <nav
        id="main-nav"
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled
            ? 'bg-[#FDFBF7]/95 backdrop-blur-md border-b border-[#1A1A1A]/10 py-3 shadow-sm'
            : 'bg-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <a href="#" className="flex items-center gap-2.5 group">
              <div className="w-9 h-9 rounded-full bg-brand-gold flex items-center justify-center p-2 shadow-inner group-hover:scale-105 transition-transform">
                <Music className="w-5 h-5 text-white" />
              </div>
              <div>
                <span className="font-serif text-lg font-bold tracking-tight text-[#1A1A1A] block leading-none">
                  SOUL
                </span>
                <span className="text-[9px] uppercase font-extrabold text-brand-gold tracking-[0.2em] block mt-0.5">
                  Performing Arts & Music
                </span>
              </div>
            </a>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center gap-6">
              {menuItems.map((item) => (
                <a
                  key={item.label}
                  href={item.href}
                  className="font-sans text-xs uppercase tracking-widest font-bold text-[#1A1A1A]/80 hover:text-brand-gold transition-colors duration-200 relative group py-2"
                >
                  {item.label}
                  <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-brand-gold transition-all duration-300 group-hover:w-full" />
                </a>
              ))}
            </div>

            {/* CTA Elements */}
            <div className="hidden sm:flex items-center gap-4">
              <a
                href="https://www.facebook.com/soulperformingmusic"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 gap-1.5 hidden xl:flex items-center text-xs font-bold uppercase tracking-widest text-[#1A1A1A]/70 hover:text-brand-gold transition-colors duration-200"
              >
                <Facebook className="w-4 h-4 text-brand-gold" />
                <span>Visit Facebook</span>
                <ExternalLink className="w-3 h-3 text-brand-gold/60" />
              </a>

              <a
                href="#booking"
                className="px-6 py-2 border border-[#1A1A1A] hover:bg-[#1A1A1A] hover:text-white transition-colors text-xs uppercase tracking-widest font-bold text-[#1A1A1A] bg-transparent"
              >
                Book Free Trial
              </a>
            </div>

            {/* Mobile Menu Button */}
            <div className="flex lg:hidden items-center gap-3">
              <a
                href="#booking"
                className="px-4 py-1.5 border border-[#1A1A1A] hover:bg-[#1A1A1A] hover:text-white transition-colors text-[10px] uppercase tracking-widest font-bold text-[#1A1A1A] bg-transparent"
              >
                Free Trial
              </a>
              <button
                type="button"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="p-2 text-[#1A1A1A] hover:text-brand-gold transition-colors"
                aria-label="Toggle menu"
              >
                {isMobileMenuOpen ? (
                  <X className="w-6 h-6" />
                ) : (
                  <Menu className="w-6 h-6" />
                )}
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile Drawer Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.2 }}
            className="fixed top-[60px] left-0 right-0 z-40 bg-[#FDFBF7] border-b border-[#1A1A1A]/10 shadow-xl py-6 px-4 flex flex-col gap-4 lg:hidden max-h-[85vh] overflow-y-auto"
          >
            {menuItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                onClick={() => setIsMobileMenuOpen(false)}
                className="font-sans text-xs uppercase tracking-widest font-bold text-[#1A1A1A] hover:text-brand-gold border-b border-[#1A1A1A]/5 pb-2.5 transition-colors text-left"
              >
                {item.label}
              </a>
            ))}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between pt-2 gap-4">
              <a
                href="https://www.facebook.com/soulperformingmusic"
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setIsMobileMenuOpen(false)}
                className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-[#1A1A1A]/70 hover:text-brand-gold transition-colors py-2 text-left"
              >
                <Facebook className="w-4.5 h-4.5 text-brand-gold" />
                <span>Visit Facebook Page</span>
                <ExternalLink className="w-3 h-3" />
              </a>

              <a
                href="#booking"
                onClick={() => setIsMobileMenuOpen(false)}
                className="px-6 py-2.5 text-center border border-[#1A1A1A] bg-[#1A1A1A] hover:bg-transparent text-white hover:text-[#1A1A1A] transition-colors text-xs uppercase tracking-widest font-bold"
              >
                Book Free Trial Now
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
