import { Program, Instructor, FaqItem, ReviewItem } from './types';

export const MUSIC_PROGRAMS: Program[] = [
  {
    id: 'piano',
    name: 'Classical & Pop Piano',
    tagline: 'Strum the keys of discipline and passion',
    iconName: 'Music',
    description: 'Comprehensive coaching for kids and adults. Learn classical masterpieces, beautiful pop chord sheets, or prep for professional ABRSM / Trinity Guildhall graded exams. Highly encouraging methods.',
    priceLabel: 'RM 240 / month',
    trialPrice: 'FREE (Normally RM 60)',
    durationLevel: '45 mins / weekly individual',
    ageGroup: 'Ages 5 to Adults',
    syllabusOverview: [
      'Sight-reading mechanics & sheet intelligence',
      'Hand postures, scales, and finger dexterity',
      'Chords, standard pop flow, and play-by-ear guidelines',
      'Graded preparation (ABRSM Grades 1 - 8)'
    ],
    image: 'https://images.unsplash.com/photo-1520523839897-bd0b52f945a0?q=80&w=600&auto=format&fit=crop',
    targetInterests: ['Classical', 'Sheet Music', 'Pop & Jazz', 'Exams']
  },
  {
    id: 'guitar',
    name: 'Acoustic & Electric Guitar',
    tagline: 'Master the strings and shape your tone',
    iconName: 'Guitar',
    description: 'From campfire strumming and basic open chords to high-gain electric guitar solos and fingerstyle arrangements. Perfect for teens and adults wanting quick, tangible progress.',
    priceLabel: 'RM 220 / month',
    trialPrice: 'FREE (Normally RM 50)',
    durationLevel: '45 mins / weekly individual',
    ageGroup: 'Ages 7 to Adults',
    syllabusOverview: [
      'Fretboard navigation, tabs, and scale theory',
      'Strumming synchronization & timing rudiments',
      'Fingerpicking, hammer-ons, and dynamic slides',
      'Improvisation, gear setup, and solo mastery'
    ],
    image: 'https://images.unsplash.com/photo-1510915361894-db8b60106cb1?q=80&w=600&auto=format&fit=crop',
    targetInterests: ['Rock & Pop', 'Chords & Strumming', 'Fingerstyle', 'Solos']
  },
  {
    id: 'vocal',
    name: 'Vocal Mastery & Performance',
    tagline: 'Find and project your authentic voice',
    iconName: 'Mic',
    description: 'Unlock your vocal range, master breath support, fine-tune pitch accuracy, and banish stage fright. Learn styling for pop, rock, musical theatre, and classical singing.',
    priceLabel: 'RM 260 / month',
    trialPrice: 'FREE (Normally RM 65)',
    durationLevel: '45 mins / weekly individual',
    ageGroup: 'Ages 6 to Adults',
    syllabusOverview: [
      'Diaphragmatic breathing & respiratory control',
      'Vocal range expansion and high-note transitions',
      'Articulating vowels & correct posture support',
      'Microphone styling, performance stance and emotions'
    ],
    image: 'https://images.unsplash.com/photo-1516280440614-37939bbacd6a?q=80&w=600&auto=format&fit=crop',
    targetInterests: ['Singing', 'Stage Projection', 'Pitch Tuning', 'Confidence']
  },
  {
    id: 'violin',
    name: 'Violin & Expressive Strings',
    tagline: 'Graceful bows and accurate intonation',
    iconName: 'Sparkles',
    description: 'Delve into the gorgeous classical depths of the violin. We combine the world-famous Suzuki method with ABRSM guidelines to foster flawless posture and superb muscle memory.',
    priceLabel: 'RM 250 / month',
    trialPrice: 'FREE (Normally RM 60)',
    durationLevel: '45 mins / weekly individual',
    ageGroup: 'Ages 5 to Adults',
    syllabusOverview: [
      'Holding stance, bow-grip stability and elbow angles',
      'Ear training for absolute micro-intonation precision',
      'Suzuki repertoire, simple duets and scales',
      'Shifting positions & deep vibrato adjustments'
    ],
    image: 'https://images.unsplash.com/photo-1465847899084-d164df4dedc6?q=80&w=600&auto=format&fit=crop',
    targetInterests: ['Classical', 'Suzuki Method', 'Orchestra Prep', 'Ear Tuning']
  },
  {
    id: 'drums',
    name: 'Drums & Rhythm Section',
    tagline: 'Unleash energetic rhythms and deep groove',
    iconName: 'Drum',
    description: 'Acquire limb separation, build speed and endurance, and learn how to hold down standard structures behind a band. Play along with your favorite pop and rock charts starting Day 1.',
    priceLabel: 'RM 245 / month',
    trialPrice: 'FREE (Normally RM 60)',
    durationLevel: '45 mins / weekly individual',
    ageGroup: 'Ages 6 to Adults',
    syllabusOverview: [
      'Basic and advanced rudiments on practice pads',
      'Independence of four limbs over dynamic grooves',
      'Metronome alignment & steady beat maintaining',
      'Signature fills, syncopated rolls, and song structures'
    ],
    image: 'https://images.unsplash.com/photo-1519892300165-cb5542fb47c7?q=80&w=600&auto=format&fit=crop',
    targetInterests: ['Beat Keeping', 'Heavy Rock & Funk', 'Coordination', 'Performance']
  },
  {
    id: 'early_childhood',
    name: 'Early Childhood Musical Spark',
    tagline: 'Joyful exploration for little creators',
    iconName: 'Baby',
    description: 'A sensory-rich group introduction for children. We use rhythm sticks, shaker eggs, light xylophones, and music games to instill foundational pitch recognition and fine-tune motor skills.',
    priceLabel: 'RM 180 / month',
    trialPrice: 'FREE (Normally RM 40)',
    durationLevel: '45 mins / weekly group class',
    ageGroup: 'Ages 3 to 5 years',
    syllabusOverview: [
      'Interactive singing, clap-back patterns, and dance',
      'Introduction to high vs low pitch, fast vs slow tempo',
      'Elementary hand movements on miniature piano keys',
      'Social playing with colorful percussion toys'
    ],
    image: 'https://images.unsplash.com/photo-1507838153414-b4b713384a76?q=80&w=600&auto=format&fit=crop',
    targetInterests: ['Toddler Group', 'Rhythm Games', 'Phonics & Melodies', 'Motor Skills']
  }
];

export const INSTRUCTORS: Instructor[] = [
  {
    id: '1',
    name: 'Teacher Sarah Lim',
    role: 'Principal & Senior Piano Educator',
    bio: 'Sarah has over 12 years of coaching experience, specializing in classical pedagogy and performance psychology. She guides students gently through high-pressure exam stress into confident players.',
    instrument: 'Piano & Music Theory',
    image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=300&auto=format&fit=crop',
    education: 'Bachelor of Music (Hons) - UCSI University',
    experience: '12+ Years Teaching Experience'
  },
  {
    id: '2',
    name: 'Teacher Adrian David',
    role: 'Lead Guitar & Ukulele Mentor',
    bio: 'Adrian is an active gigging musician in Kuala Lumpur who brings real-world stage performance wisdom to his lessons. He focuses on modern pop/rock techniques, gear guidance, and play-by-ear systems.',
    instrument: 'Acoustic Guitar, Electric Guitar & Ukulele',
    image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=300&auto=format&fit=crop',
    education: 'Associate Diploma in Guitar Performance - Trinity Guildhall',
    experience: '8+ Years teaching & performance'
  },
  {
    id: '3',
    name: 'Teacher Michelle Teh',
    role: 'Soprano Vocalist & Performance Coach',
    bio: 'Michelle specializes in vocal health, range elongation, and diaphragmatic support. She teaches students to tap into their authentic tone across Pop, Musical Theatre, and Classical styles.',
    instrument: 'Vocal Mastery & Audition Coaching',
    image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=300&auto=format&fit=crop',
    education: 'Master of Arts in Vocal Pedagogy - Royal Academy of Music (UK)',
    experience: '9+ Years as international vocal tutor'
  },
  {
    id: '4',
    name: 'Teacher Darren Wong',
    role: 'Rhythm Architect & Drum Instructor',
    bio: 'Darren makes drum training energetic, highly tailored and fun. He emphasizes micro-timing, hand rudiments, limb independence, and helps students play along with full tracks starting single sessions.',
    instrument: 'Drums & Rhythmic Coordination',
    image: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?q=80&w=300&auto=format&fit=crop',
    education: 'Registered Grade 8 certified under RockSchool UK',
    experience: '7+ Years inspiring young drummers'
  }
];

export const FAQS: FaqItem[] = [
  {
    category: 'General',
    question: 'How do I sign up for the free trial lesson?',
    answer: 'Simply fill out our interactive Booking Portal below or message us! We will coordinate with you via WhatsApp to align a free 30-minute individual time slot matching your preferred schedule.'
  },
  {
    category: 'Instruments',
    question: 'Do I need to own an instrument before starting classes?',
    answer: "No, you do not! For your free trial, we provide studio instruments (pianos, acoustic guitars, drum kits, violins) free of charge. Once you decide to enroll, our teachers will guide you with trustworthy, budget-friendly brands so you do not overspend on your first instrument."
  },
  {
    category: 'Ages',
    question: 'Am I too old to learn? Is there an adult program?',
    answer: "Absolutely not! Over 35% of our musical community at Soul Performing Arts are adult learners—ranging from tech professionals, working parents, to retired seniors. We customize pop songbooks and fast-track chords for adults so you do not have to study children nursery tracks."
  },
  {
    category: 'Exams',
    question: 'Do you prepare students for certified international examinations?',
    answer: 'Yes. We prepare students for internationally accredited examinations including ABRSM (Associated Board of the Royal Schools of Music, UK), Trinity College London, and Rockschool UK across classical theory, classical playing, and modern pop/rock.'
  },
  {
    category: 'Logistics',
    question: 'What happens if a student misses a scheduled class?',
    answer: 'We have student-friendly policies! If you notify us at least 24 hours in advance of a travel, exam, or illness, we will schedule a 1-to-1 replacement make-up class so your paid tuition is never wasted.'
  }
];

export const TESTIMONIALS: ReviewItem[] = [
  {
    id: 't1',
    author: 'Puan Melissa Razak',
    relation: 'Parent of Adam (7y, Piano)',
    rating: 5,
    content: "Adam used to give up easily on keys, but Teacher Sarah has a magic touch. She makes lesson plans so fun and interactive. Now Adam runs to the piano every evening. We are very proud of his recent recital performance!",
    instrument: 'Piano',
    avatarId: 'MR'
  },
  {
    id: 't2',
    author: 'Daniel Heng',
    relation: 'Adult Student (Acoustic Guitar)',
    rating: 5,
    content: 'Joining Soul Performing Arts was the best hobby decision I made as an adult. Teacher Adrian does not force boring classic files onto me. He lets me pick my favorite acoustic ballads and shows me practical chord tricks. Highly recommended!',
    instrument: 'Guitar',
    avatarId: 'DH'
  },
  {
    id: 't3',
    author: 'Sharon K.',
    relation: 'Parent of Chloe (11y, Vocal & Violin)',
    rating: 5,
    content: 'Very supportive atmosphere. Soul Performing Arts is not just a room with teachers—they actively engineer live stage performances and student recitals in Malaysia. Chloe has developed amazing posture on violin and high performance confidence!',
    instrument: 'Vocal & Violin',
    avatarId: 'SK'
  }
];
